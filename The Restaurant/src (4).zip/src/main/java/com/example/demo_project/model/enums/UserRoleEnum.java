package com.example.demo_project.model.enums;

public enum UserRoleEnum {
    ADMIN,
    USER;
}
