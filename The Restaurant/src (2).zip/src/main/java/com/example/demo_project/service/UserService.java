package com.example.demo_project.service;


import com.example.demo_project.model.dto.UserRegisterDTO;

public interface UserService {

    void registerUser(UserRegisterDTO userRegisterDTO);

}
