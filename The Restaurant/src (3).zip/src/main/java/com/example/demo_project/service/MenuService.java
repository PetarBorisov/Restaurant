package com.example.demo_project.service;

public interface MenuService {


}
