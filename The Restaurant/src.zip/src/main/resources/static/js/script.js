console.log('Script.js loaded');

function addComment() {
    console.log('Trying to add a comment.');
    var commentText = document.getElementById('commentText').value;

    fetch('http://localhost:8080/api/comments/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Origin': 'http://localhost:8080'
        },
        body: JSON.stringify({ text: commentText }),
        credentials: 'include'
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok: ' + response.status + ' ' + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            console.log('Comment added:', data);
            loadComments();
        })
      .catch(error => console.error('Error:', error));
}

function deleteComment(id) {
    fetch('/api/comments/' + id, {
        method: 'DELETE'
    })
        .then(response => {
            if (response.ok) {
                return response.json();  // Връщаме Promise, който предоставя JSON от отговора
            } else {
                throw new Error('Network response was not ok: ' + response.status + ' ' + response.statusText);
            }
        })
        .then(data => {
            console.log('Comment deleted:', data);
            loadComments();
        })
        .catch(error => console.error('Error:', error));
}

function loadComments() {
    fetch('/api/comments')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            var commentsList = document.getElementById('commentsList');
            commentsList.innerHTML = '';

            data.forEach(function (comment) {
                var listItem = document.createElement('li');
                listItem.innerHTML = comment.text + ' <button onclick="deleteComment(' + comment.id + ')">Изтрий</button>';
                commentsList.appendChild(listItem);
            });
        })
        .catch(error => console.error('Error:', error));
}

document.addEventListener('DOMContentLoaded', function () {
    loadComments();
});