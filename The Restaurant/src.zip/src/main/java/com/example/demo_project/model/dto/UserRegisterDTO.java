package com.example.demo_project.model.dto;

public record UserRegisterDTO(String firstName,
                              String lastName,
                              String email,
                              String password,
                              String confirmPassword) {
}
