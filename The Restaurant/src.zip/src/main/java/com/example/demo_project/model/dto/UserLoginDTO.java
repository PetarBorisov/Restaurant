package com.example.demo_project.model.dto;

public record UserLoginDTO(String email,
                           String password) {
}
