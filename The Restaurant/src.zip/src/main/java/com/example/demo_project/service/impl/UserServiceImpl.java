package com.example.demo_project.service.impl;


import com.example.demo_project.model.dto.UserLoginDTO;
import com.example.demo_project.model.dto.UserRegisterDTO;
import com.example.demo_project.model.entity.UserEntity;
import com.example.demo_project.repository.UserRepository;
import com.example.demo_project.service.UserService;
import com.example.demo_project.util.CurrentUser;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final CurrentUser currentUser;

    public UserServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder, CurrentUser currentUser) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.currentUser = currentUser;
    }


    @Override
    public void registerUser(UserRegisterDTO userRegisterDTO) {

        userRepository.save(map(userRegisterDTO));
    }

    @Override
    public boolean loginUser(UserLoginDTO userLoginDTO) {

             var userEntity = userRepository
                     .findByEmail(userLoginDTO.email())
                     .orElse(null);

             boolean loginSuccess = false;

             if (userEntity != null) {
                 String rawPassword = userLoginDTO.password();
                 String encodedPassword = userEntity.getPassword();

                 loginSuccess = encodedPassword != null &&
                         passwordEncoder.matches(rawPassword, encodedPassword);

                 if (loginSuccess) {
                     currentUser.setLogged(true)
                             .setFirstName(userEntity.getFirstName())
                             .setLastName(userEntity.getLastName());
                 }else {
                     currentUser.logoutUser();
                 }
             }
             return loginSuccess;

    }

    @Override
    public void logout() {
        currentUser.logoutUser();
    }

    private UserEntity map(UserRegisterDTO userRegisterDTO) {
        return new UserEntity()
                .setActive(true)
                .setFirstName(userRegisterDTO.firstName())
                .setLastName(userRegisterDTO.lastName())
                .setEmail(userRegisterDTO.email())
                .setPassword(passwordEncoder.encode(userRegisterDTO.password()));
    }
}
